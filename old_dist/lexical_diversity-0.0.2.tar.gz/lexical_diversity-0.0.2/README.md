# To install using pip:

    pip install lexical-diversity


